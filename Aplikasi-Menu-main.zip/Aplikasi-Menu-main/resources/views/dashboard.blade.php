@extends('crud.dash')

@section('title', 'Dashboard - Laravel Admin Panel With Login and Registration')

@section('contents')
<div class="row">
    Dashboard
</div>
@endsection